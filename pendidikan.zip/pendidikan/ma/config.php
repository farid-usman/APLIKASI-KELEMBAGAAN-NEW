<?php
$cfg = [
    'label'  => 'MA',
    'table'  => 'ma',
    'fields' => [
        'id'     => 'id',        // primary key
        'no'     => 'no',        // nomor urut
        'nsm'    => 'nsm_ma',    // NSM Madrasah Aliyah
        'npsn'   => 'npsn_ma',   // NPSN Madrasah Aliyah
        'nama'   => 'nm_ma',     // Nama Madrasah
        'kec'    => 'kec_ma',    // Kecamatan
        'kepsek' => 'kepsek_ma', // Kepala Sekolah
        'tipe'   => 'tipe_ma',   // Negeri / Swasta
        'hp'     => 'nohp_ma',  
        'agenda' => 'agenda2025' // Kolom untuk Agenda 2025
    ]
];
