<?php
$cfg = [
    'label'  => 'MI',
    'table'  => 'mi',
    'fields' => [
        'id'     => 'id',        // primary key
        'no'     => 'no',        // nomor urut
        'nsm'    => 'nsm_mi',    // NSM Madrasah Ibtidaiyah
        'npsn'   => 'npsn_mi',   // NPSN Madrasah Ibtidaiyah
        'nama'   => 'nm_mi',     // Nama Madrasah
        'kec'    => 'kec_mi',    // Kecamatan
        'kepsek' => 'kepsek_mi', // Kepala Sekolah
        'tipe'   => 'tipe_mi',   // Negeri / Swasta
        'hp'     => 'nohp_mi',  
        'agenda' => 'agenda2025' // Kolom untuk Agenda 2025
    ]
];
