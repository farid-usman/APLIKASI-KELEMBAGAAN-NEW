<?php
require __DIR__ . "/../includes/koneksi.php";

$j  = isset($_GET['j']) ? strtoupper($_GET['j']) : '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

switch ($j) {
    case 'MA':  require __DIR__ . '/../ma/config.php'; break;
    case 'MTS': require __DIR__ . '/../mts/config.php'; break;
    case 'MI':  require __DIR__ . '/../mi/config.php'; break;
    default: die("Parameter jenjang tidak valid.");
}

$table = $cfg['table'];
$f     = $cfg['fields'];

// hanya kosongkan kolom agenda2025, data madrasah tetap utuh
$sql = "UPDATE `$table` SET {$f['agenda']}='' WHERE id=$id";

if (mysqli_query($conn, $sql)) {
    header("Location: hasil.php?j=$j&msg=Agenda berhasil dihapus");
    exit;
} else {
    die("Error: " . mysqli_error($conn));
}
