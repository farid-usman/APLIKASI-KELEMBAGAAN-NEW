<?php
require __DIR__ . "/../includes/koneksi.php";

/* Jenjang */
$j = isset($_GET['j']) ? strtoupper($_GET['j']) : '';
switch ($j) {
  case 'MA':  require __DIR__ . '/../ma/config.php'; break;
  case 'MTS': require __DIR__ . '/../mts/config.php'; break;
  case 'MI':  require __DIR__ . '/../mi/config.php'; break;
  default: die("Parameter jenjang tidak valid. Gunakan ?j=MA / MTS / MI");
}

if (!isset($cfg) || !is_array($cfg)) {
  die("config.php untuk jenjang $j tidak mengembalikan \$cfg yang valid.");
}

$table = $cfg['table'] ?? '';
$f     = $cfg['fields'] ?? [];

if ($table === '' || !is_array($f)) {
  die("Konfigurasi untuk jenjang $j tidak lengkap. Cek 'table' dan 'fields'.");
}

/* ===== Validasi mapping kolom wajib ===== */
$required = ['id','no','nsm','npsn','nama','kec','kepsek','tipe','agenda'];
$missing = [];
foreach ($required as $k) {
  if (!isset($f[$k]) || trim((string)$f[$k]) === '') {
    $missing[] = $k;
  }
}
if ($missing) {
  $list = implode(', ', $missing);
  die("Mapping 'fields' untuk jenjang $j belum lengkap. Harus memuat: $list. 
Silakan perbaiki modules/".strtolower($j)."/config.php agar tiap kunci memetakan ke NAMA KOLOM di tabel '$table'.");
}

/* Ambil nama kolom dari mapping */
$col_id  = $f['id'];
$col_no  = $f['no'];
$col_nsm = $f['nsm'];
$col_npsn= $f['npsn'];
$col_nama= $f['nama'];
$col_kec = $f['kec'];
$col_kep = $f['kepsek'];
$col_tipe= $f['tipe'];
$col_ag  = $f['agenda'];

/* Tambahan opsional HP */
$col_hp = $f['hp'] ?? null;   // contoh: nohp_ma / nohp_mts / nohp_mi
$hasHp  = !empty($col_hp);

/* Pencarian */
$q = trim($_GET['q'] ?? '');
$canSearch = (mb_strlen($q) >= 3);
$where = '';
if ($canSearch) {
  $qEsc = mysqli_real_escape_string($conn, $q);
  $where = "WHERE `$col_npsn` LIKE '%$qEsc%' OR `$col_nama` LIKE '%$qEsc%'";
}

/* Pagination */
define('PER_PAGE', 50);
$page   = max(1, (int)($_GET['page'] ?? 1));
$offset = (int)(($page - 1) * PER_PAGE);

/* Hitung total baris (sesuai filter) */
$sqlCount = "SELECT COUNT(*) AS n FROM `$table` $where";
$rc = mysqli_query($conn, $sqlCount) or die("Query error: " . mysqli_error($conn));
$total_rows  = (int) mysqli_fetch_assoc($rc)['n'];
$total_pages = max(1, (int)ceil($total_rows / PER_PAGE));

/* Ambil data halaman ini — pilih kolom spesifik (sesuai filter) */
$sql = "
  SELECT
    `$col_id`  AS id,
    `$col_no`  AS no,
    `$col_nsm` AS nsm,
    `$col_npsn`AS npsn,
    `$col_nama`AS nama,
    `$col_kec` AS kec,
    `$col_kep` AS kepsek,
    `$col_tipe`AS tipe,
    " . ($hasHp ? "`$col_hp` AS hp," : "'' AS hp,") . "
    `$col_ag`  AS agenda
  FROM `$table`
  $where
  ORDER BY `$col_no` ASC
  LIMIT ".PER_PAGE." OFFSET $offset
";
$result = mysqli_query($conn, $sql);
if (!$result) die("Query error: " . mysqli_error($conn));

$msg = $_GET['msg'] ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Rekap Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></title>
<style>
  :root{ --green:#2e7d32; --green-dark:#1b5e20; --slate:#64748b; }
  body{font-family:Arial, sans-serif;background:#f9fafb;margin:0;padding:20px}
  h2{color:var(--green); margin:0 0 10px}
  .container{max-width:1400px;margin:auto}
  .msg{margin:10px 0;color:var(--green);font-weight:bold}
  a.back{display:inline-block;margin:0 0 12px;padding:8px 12px;background:#4caf50;color:#fff;
         text-decoration:none;border-radius:6px}
  a.back:hover{background:var(--green-dark)}

  .search-row{display:flex;gap:8px;align-items:center;margin:8px 0 14px}
  .search-row input[type=text]{padding:8px;border:1px solid #cbd5e1;border-radius:6px;width:320px}
  .btn{display:inline-block;padding:8px 12px;border:none;border-radius:6px;cursor:pointer;text-decoration:none;color:#fff;background:#4caf50}
  .btn:hover{background:#2e7d32}
  .btn-reset{background:#64748b} .btn-reset:hover{background:#475569}

  table{
    border-collapse:collapse; width:100%; background:#fff;
    box-shadow:0 4px 12px rgba(0,0,0,.08); table-layout:auto;
  }
  th,td{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}
  th{background:var(--green);color:#fff}
  tr:nth-child(even){background:#f2f2f2}

  .agenda-text{white-space:pre-wrap; word-break:break-word; overflow-wrap:anywhere; color:#111827; max-height:500px; overflow:auto;}
  .muted{color:var(--slate);font-size:12px}

  .td-aksi{ display:flex; gap:6px; align-items:center; flex-wrap:wrap; min-width:140px }
  .btn.edit{background:#1976d2}.btn.edit:hover{background:#0d47a1}
  .btn.delete{background:#e53935}.btn.delete:hover{background:#b71c1c}
  .btn.copy{background:#14b8a6}.btn.copy:hover{background:#0f766e}

  .pager{display:flex;gap:8px;align-items:center;justify-content:flex-end;margin:10px 0}
  .pager a,.pager span{
    display:inline-block;padding:6px 10px;border-radius:6px;border:1px solid #cbd5e1;
    text-decoration:none;color:#111827;background:#fff
  }
  .pager a:hover{background:#f1f5f9}
  .pager .active{background:#2e7d32;color:#fff;border-color:#2e7d32}
  .pager .muted{border-color:transparent;background:transparent;color:#64748b}
</style>
</head>
<body>
<div class="container">
  <h2>Rekap Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></h2>
  <a class="back" href="../<?= strtolower($cfg['label']) ?>/index.php">← Kembali ke Dashboard <?= htmlspecialchars($cfg['label']) ?></a>
  <?php if($msg): ?><div class="msg"><?= htmlspecialchars($msg) ?></div><?php endif; ?>

  <!-- Form Pencarian -->
  <form class="search-row" method="get">
    <input type="hidden" name="j" value="<?= htmlspecialchars($cfg['label']) ?>">
    <input type="text" name="q" placeholder="Cari NPSN / Nama Madrasah (min. 3 huruf)..." value="<?= htmlspecialchars($q) ?>">
    <button class="btn" type="submit">Cari</button>
    <?php if ($q !== ''): ?>
      <a class="btn btn-reset" href="hasil.php?j=<?= urlencode($cfg['label']) ?>">Reset</a>
    <?php endif; ?>
  </form>

  <div class="pager">
    <?php
      $base = "hasil.php?j=" . urlencode($cfg['label']);
      if ($q !== '') $base .= "&q=" . urlencode($q);
    ?>
    <?php if ($canSearch): ?>
      <span class="muted">Hasil untuk: <strong><?= htmlspecialchars($q) ?></strong> — <?= number_format($total_rows) ?> data</span>
    <?php else: ?>
      <span class="muted">Total: <?= number_format($total_rows) ?> data<?= ($q!==''?' (ketik ≥3 huruf untuk mencari)':'') ?></span>
    <?php endif; ?>
  </div>

  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>NSM</th>
        <th>NPSN</th>
        <th>Nama Madrasah</th>
        <th>Kecamatan</th>
        <th>Kepala Sekolah</th>
        <th>Tipe</th>
        <th>No HP</th>
        <th>Agenda 2025</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
      <?php $agenda = trim((string)($row['agenda'] ?? '')); ?>
      <tr>
        <td><?= htmlspecialchars($row['no']) ?></td>
        <td><?= htmlspecialchars($row['nsm']) ?></td>
        <td><?= htmlspecialchars($row['npsn']) ?></td>
        <td><?= htmlspecialchars($row['nama']) ?></td>
        <td><?= htmlspecialchars($row['kec']) ?></td>
        <td><?= htmlspecialchars($row['kepsek']) ?></td>
        <td><?= htmlspecialchars($row['tipe']) ?></td>
        <td><?= htmlspecialchars($row['hp'] ?? '') ?></td>
        <td>
          <div class="agenda-text"><?= htmlspecialchars($agenda) ?></div>
          <?php if ($agenda === ''): ?>
            <div class="muted">— belum diisi —</div>
          <?php endif; ?>
        </td>
        <td class="td-aksi">
          <a class="btn edit" href="edit_agenda.php?j=<?=urlencode($cfg['label'])?>&id=<?= urlencode($row['id']) ?>">Edit</a>
          <a class="btn delete" href="hapus_agenda.php?j=<?=urlencode($cfg['label'])?>&id=<?= urlencode($row['id']) ?>"
             onclick="return confirm('Hapus (kosongkan) Agenda 2025 madrasah ini?')">Hapus</a>
          <?php if ($agenda !== ''): ?>
            <a class="btn copy" href="#" data-copy="<?= htmlspecialchars($agenda, ENT_QUOTES) ?>" onclick="return copyAgenda(this)">Salin</a>
          <?php endif; ?>
        </td>
      </tr>
    <?php endwhile; ?>
    </tbody>
  </table>

  <div class="pager">
    <?php
      // pagination links (ikut filter q)
      if ($page > 1) {
        echo '<a href="'.$base.'&page=1">&laquo; Awal</a>';
        echo '<a href="'.$base.'&page='.($page-1).'">&lsaquo; Prev</a>';
      } else {
        echo '<span class="muted">&laquo; Awal</span><span class="muted">&lsaquo; Prev</span>';
      }
      $start = max(1, $page - 2);
      $end   = min($total_pages, $page + 2);
      for ($p=$start; $p<=$end; $p++) {
        if ($p == $page) echo '<span class="active">'.$p.'</span>';
        else echo '<a href="'.$base.'&page='.$p.'">'.$p.'</a>';
      }
      if ($page < $total_pages) {
        echo '<a href="'.$base.'&page='.($page+1).'">Next &rsaquo;</a>';
        echo '<a href="'.$base.'&page='.$total_pages.'">Akhir &raquo;</a>';
      } else {
        echo '<span class="muted">Next &rsaquo;</span><span class="muted">Akhir &raquo;</span>';
      }
    ?>
  </div>
</div>

<script>
  function copyAgenda(el){
    const txt = el.getAttribute('data-copy') || '';
    if (!navigator.clipboard) {
      const ta = document.createElement('textarea');
      ta.value = txt; document.body.appendChild(ta);
      ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
    } else {
      navigator.clipboard.writeText(txt);
    }
    el.textContent = 'Tersalin'; setTimeout(()=>{ el.textContent='Salin'; }, 1200);
    return false;
  }
</script>
</body>
</html>
