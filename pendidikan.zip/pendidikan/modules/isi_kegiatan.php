<?php
require __DIR__ . "/../includes/koneksi.php";

/* tentukan jenjang */
$j = isset($_GET['j']) ? strtoupper($_GET['j']) : '';
switch ($j) {
  case 'MA':  require __DIR__ . '/../ma/config.php';  break;
  case 'MTS': require __DIR__ . '/../mts/config.php'; break;
  case 'MI':  require __DIR__ . '/../mi/config.php';  break;
  default: die("Parameter jenjang tidak valid. Gunakan ?j=MA / MTS / MI");
}

$table = $cfg['table'];
$f     = $cfg['fields'];

/* fallback aman */
$idCol     = $f['id']     ?? 'id';
$noCol     = $f['no']     ?? 'no';
$namaCol   = $f['nama']   ?? 'nama';
$npsnCol   = $f['npsn']   ?? 'npsn';
$agendaCol = $f['agenda'] ?? 'agenda2025';

/* mode & query */
$mode = $_GET['mode'] ?? 'search';
$q    = trim($_GET['q'] ?? '');
$canSearch = (mb_strlen($q) >= 3);

/* proses update/hapus agenda */
$msg = '';
$lastSavedId = 0;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id     = (int)($_POST['id'] ?? 0);
    $op     = $_POST['op'] ?? 'simpan';

    if ($op === 'hapus') {
        $sqlU = "UPDATE `$table` SET `$agendaCol`='' WHERE `$idCol`=$id";
        if (mysqli_query($conn, $sqlU)) {
            $msg = "Agenda berhasil dihapus.";
            $lastSavedId = $id;
        } else {
            $msg = "Error: " . mysqli_error($conn);
        }
    } else {
        $agendaRaw = $_POST['agenda2025'] ?? '';
        // Jika kolom masih VARCHAR, Anda bisa batasi panjangnya dengan mb_substr di sini.
        $agenda = mysqli_real_escape_string($conn, $agendaRaw);
        $sqlU   = "UPDATE `$table` SET `$agendaCol`='$agenda' WHERE `$idCol`=$id";
        if (mysqli_query($conn, $sqlU)) {
            $msg = "Agenda berhasil diperbarui.";
            $lastSavedId = $id;
        } else {
            $msg = "Error: " . mysqli_error($conn);
        }
    }
}

/* ambil data */
$result = null; $result_count = 0; $info = '';
if ($mode === 'all') {
    $sql = "SELECT `$idCol` AS id, `$noCol` AS no, `$namaCol` AS nama, `$agendaCol` AS agenda
            FROM `$table`
            ORDER BY `$noCol` ASC";
    $result = mysqli_query($conn, $sql) or die("Query error: " . mysqli_error($conn));
    $result_count = mysqli_num_rows($result);
    $info = "Menampilkan semua madrasah (<strong>{$result_count}</strong> data)";
} elseif ($canSearch) {
    $qEsc = mysqli_real_escape_string($conn, $q);
    $sql = "SELECT `$idCol` AS id, `$noCol` AS no, `$namaCol` AS nama, `$agendaCol` AS agenda
            FROM `$table`
            WHERE `$npsnCol` LIKE '%$qEsc%' OR `$namaCol` LIKE '%$qEsc%'
            ORDER BY `$noCol` ASC";
    $result = mysqli_query($conn, $sql) or die("Query error: " . mysqli_error($conn));
    $result_count = mysqli_num_rows($result);
    $info = "Hasil untuk: <strong>".htmlspecialchars($q)."</strong> (<strong>{$result_count}</strong> data)";
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Isi / Perbarui Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></title>
  <style>
    body{font-family:Arial,sans-serif;background:#f9fafb;margin:0;padding:20px}
    h2{color:#2e7d32}
    .container{max-width:1200px;margin:auto}
    a.back{display:inline-block;margin:0 0 12px;padding:8px 12px;background:#4caf50;color:#fff;text-decoration:none;border-radius:6px}
    a.back:hover{background:#2e7d32}
    .row{display:flex;gap:8px;align-items:center;margin-bottom:12px}
    input[type=text]{padding:8px;border:1px solid #cbd5e1;border-radius:6px;width:320px}
    .btn{display:inline-block;padding:8px 12px;border:none;background:#4caf50;color:#fff;border-radius:6px;cursor:pointer;text-decoration:none}
    .btn:hover{background:#2e7d32}
    .btn-secondary{background:#64748b}.btn-secondary:hover{background:#475569}
    .btn-danger{background:#e53935}.btn-danger:hover{background:#b71c1c}
    .btn-edit{background:#1976d2}.btn-edit:hover{background:#0d47a1}
    .note{color:#64748b;margin:8px 0 16px}
    .msg{margin:10px 0;color:#2e7d32;font-weight:bold}

    /* ====== TABEL ====== */
    table.agenda{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,.08)}
    th,td{border:1px solid #ddd;padding:8px;text-align:left;vertical-align:top}
    th{background:#2e7d32;color:#fff}
    tr:nth-child(even){background:#f2f2f2}
    th.agenda-col{width:55%}
    .agenda-cell{padding:10px}

    /* Textarea auto grow (default kecil) */
    .agenda-input{
      width:100%;
      height:36px; min-height:36px; max-height:300px;
      resize:none; overflow:hidden; box-sizing:border-box;
      padding:8px 10px;
      border:1px solid #cbd5e1; border-radius:8px; background:#fff;
      transition:all .15s ease; line-height:1.35; font-family:inherit; font-size:14px;
    }
    .agenda-input:focus{
      outline:none; border-color:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.15);
    }
    .agenda-cell.saved{ background:#f0fdf4; }
    .agenda-cell.saved .agenda-input{
      border-color:transparent; background:transparent; font-weight:600; color:#166534; padding:0;
    }

    /* counter karakter */
    .char-note{display:block;color:#64748b;font-size:12px;margin-top:4px}

    /* tombol sejajar */
    .td-aksi{
      display:flex; gap:6px; align-items:center; flex-wrap:wrap;
      min-width:220px; padding:10px;
    }
    .td-aksi form{ margin:0 }
    .btn-save{background:#22c55e}.btn-save:hover{background:#16a34a}
  </style>
</head>
<body>
<div class="container">
  <h2>Isi / Perbarui Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></h2>

  <a class="back" href="../<?= strtolower($cfg['label']) ?>/index.php">← Kembali ke Dashboard <?= htmlspecialchars($cfg['label']) ?></a>

  <!-- Form Pencarian -->
  <form class="row" method="get">
    <input type="hidden" name="j" value="<?= htmlspecialchars($cfg['label']) ?>">
    <?php if ($mode !== 'all'): ?><input type="hidden" name="mode" value="search"><?php endif; ?>
    <input type="text" name="q" placeholder="Cari NPSN / Nama Madrasah (min. 3 huruf)..." value="<?= htmlspecialchars($q) ?>">
    <button class="btn" type="submit">Cari</button>
    <a class="btn btn-secondary" href="?j=<?=urlencode($cfg['label'])?>&mode=all">Reset</a>
  </form>

  <?php if ($msg): ?><div class="msg"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
  <?php if ($info): ?><div class="note"><?= $info ?></div><?php endif; ?>

  <?php if ($mode !== 'all' && $q === ''): ?>
    <div class="note">Silakan ketik minimal <strong>3 huruf</strong> untuk menampilkan hasil pencarian.</div>
  <?php endif; ?>

  <?php if ($result): ?>
    <table class="agenda">
      <tr>
        <th style="width:80px">No</th>
        <th style="width:35%">Nama Madrasah</th>
        <th class="agenda-col">Agenda 2025</th>
        <th style="width:260px">Aksi</th>
      </tr>
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <?php
          $val = trim((string)($row['agenda'] ?? ''));
          $isSaved = ($val !== '') || ((int)$row['id'] === (int)$lastSavedId);
          $savedClass = $isSaved ? ' saved' : '';
          $rid = (int)$row['id'];
        ?>
        <tr id="row-<?= $rid ?>">
          <td><?= htmlspecialchars($row['no'] ?? '') ?></td>
          <td><?= htmlspecialchars($row['nama'] ?? '') ?></td>

          <td class="agenda-cell<?= $savedClass ?>">
            <form method="post" id="form-<?= $rid ?>" class="form-simpan">
              <textarea class="agenda-input" name="agenda2025"
                        oninput="autoGrow(this)"><?= htmlspecialchars($val) ?></textarea>
              <small class="char-note">
                <span class="char" data-max="65535">0</span> karakter
              </small>
              <input type="hidden" name="id" value="<?= $rid ?>">
              <input type="hidden" name="op" value="simpan">
            </form>
          </td>

          <td class="td-aksi">
            <button class="btn btn-save" type="submit" form="form-<?= $rid ?>">Simpan</button>
            <a class="btn btn-edit" href="edit_agenda.php?j=<?=urlencode($cfg['label'])?>&id=<?= $rid ?>">Edit</a>
            <form method="post" onsubmit="return confirm('Hapus (kosongkan) Agenda 2025 untuk madrasah ini?')">
              <input type="hidden" name="id" value="<?= $rid ?>">
              <input type="hidden" name="op" value="hapus">
              <button class="btn btn-danger" type="submit">Hapus</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  <?php endif; ?>
</div>

<script>
  const MIN_HEIGHT = 36;

  function autoGrow(el){
    el.style.height = 'auto';
    const h = Math.max(MIN_HEIGHT, el.scrollHeight);
    el.style.height = h + 'px';
  }

  document.addEventListener('DOMContentLoaded', function(){
    document.querySelectorAll('.agenda-cell .agenda-input').forEach(function(inp){
      // tinggi awal + grow jika ada isi
      autoGrow(inp);
      if ((inp.value || '').trim() !== '') {
        const cell = inp.closest('.agenda-cell');
        if (cell) cell.classList.add('saved');
      } else {
        inp.style.height = MIN_HEIGHT + 'px';
      }
      // grow saat mengetik & hapus state saved (menandakan sedang edit)
      inp.addEventListener('input', function(){
        autoGrow(inp);
        const cell = inp.closest('.agenda-cell');
        if (cell) cell.classList.remove('saved');
        // update counter
        const counter = cell?.querySelector('.char');
        const max = Number(counter?.dataset.max || '65535');
        if (counter) counter.textContent = (inp.value || '').length + ' / ' + max;
      });
    });

    // inisialisasi counter karakter
    document.querySelectorAll('.agenda-cell').forEach(function(cell){
      const inp = cell.querySelector('.agenda-input');
      const counter = cell.querySelector('.char');
      const max = Number(counter?.dataset.max || '65535');
      if (inp && counter) {
        counter.textContent = (inp.value || '').length + ' / ' + max;
      }
    });
  });
</script>
</body>
</html>
