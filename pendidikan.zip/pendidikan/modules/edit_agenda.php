<?php
require __DIR__ . "/../includes/koneksi.php";

/* parameter */
$j  = isset($_GET['j']) ? strtoupper($_GET['j']) : '';
$id = (int)($_GET['id'] ?? 0);

/* mapping jenjang */
switch ($j) {
  case 'MA':  require __DIR__ . '/../ma/config.php';  break;
  case 'MTS': require __DIR__ . '/../mts/config.php'; break;
  case 'MI':  require __DIR__ . '/../mi/config.php';  break;
  default: die("Parameter jenjang tidak valid. Gunakan ?j=MA / MTS / MI");
}

$table = $cfg['table'];
$f     = $cfg['fields'];

/* fallback aman nama kolom */
$idCol     = $f['id']     ?? 'id';
$noCol     = $f['no']     ?? 'no';
$namaCol   = $f['nama']   ?? 'nama';
$agendaCol = $f['agenda'] ?? 'agenda2025';

/* proses simpan */
$flash = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $idPost = (int)($_POST['id'] ?? 0);
  $agendaRaw = $_POST['agenda2025'] ?? '';
  // Jika kolom masih VARCHAR, Anda bisa batasi panjangnya:
  // $agendaRaw = mb_substr($agendaRaw, 0, 65535);
  $agenda = mysqli_real_escape_string($conn, $agendaRaw);

  $sqlU = "UPDATE `$table` SET `$agendaCol`='$agenda' WHERE `$idCol`=$idPost";
  if (mysqli_query($conn, $sqlU)) {
    $flash = "Agenda berhasil diperbarui.";
    $id = $idPost; // tetap di halaman yang sama
  } else {
    $flash = "Error: " . mysqli_error($conn);
  }
}

/* ambil data 1 baris */
$sql = "SELECT `$idCol` AS id, `$noCol` AS no, `$namaCol` AS nama, `$agendaCol` AS agenda
        FROM `$table` WHERE `$idCol`=$id LIMIT 1";
$res = mysqli_query($conn, $sql) or die("Query error: " . mysqli_error($conn));
$row = mysqli_fetch_assoc($res);
if (!$row) die("Data tidak ditemukan.");
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Edit Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></title>
<style>
  body{font-family:Arial,sans-serif;background:#f3f5f7;margin:0}
  .container{max-width:900px;margin:40px auto;padding:0 16px}
  h1{color:#256c2d;font-size:28px;margin:0 0 10px}
  a.back{display:inline-block;margin:10px 0 20px;padding:8px 12px;background:#4caf50;color:#fff;
         text-decoration:none;border-radius:6px}
  a.back:hover{background:#2e7d32}

  .card{background:#fff;border-radius:10px;box-shadow:0 6px 18px rgba(0,0,0,.08);padding:18px}
  .row{margin-bottom:14px}
  label{display:block;font-weight:bold;margin-bottom:6px;color:#1f2937}
  input[type=text], .textarea{
    width:100%;box-sizing:border-box;border:1px solid #cbd5e1;border-radius:8px;
    padding:10px 12px;background:#f8fafc;font-size:14px;color:#111827
  }
  input[readonly]{background:#f1f5f9;color:#374151}
  .btn{display:inline-block;padding:10px 14px;border:none;border-radius:8px;color:#fff;
       background:#22c55e;cursor:pointer}
  .btn:hover{background:#16a34a}
  .msg{margin:12px 0 0;color:#166534;font-weight:bold}

  /* Textarea compact + auto-grow */
  textarea.agenda-input{
    width:100%; height:36px; min-height:36px; max-height:400px;
    resize:none; overflow:hidden; box-sizing:border-box;
    padding:10px 12px; border:1px solid #cbd5e1; border-radius:8px;
    background:#fff; line-height:1.4; font-size:14px; font-family:inherit;
    transition:all .15s ease;
  }
  textarea.agenda-input:focus{
    outline:none; border-color:#22c55e; box-shadow:0 0 0 3px rgba(34,197,94,.15);
  }
  .char-note{display:block;color:#64748b;font-size:12px;margin-top:6px}
</style>
</head>
<body>
<div class="container">
  <h1>Edit Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></h1>
  <a class="back" href="hasil.php?j=<?= urlencode($cfg['label']) ?>">← Kembali ke Rekap</a>

  <div class="card">
    <form method="post">
      <div class="row">
        <label>Nama Madrasah:</label>
        <input type="text" value="<?= htmlspecialchars($row['nama'] ?? '') ?>" readonly>
      </div>

      <div class="row">
        <label>Agenda 2025:</label>
        <textarea class="agenda-input" name="agenda2025" oninput="autoGrow(this)"><?= htmlspecialchars(trim((string)($row['agenda'] ?? ''))) ?></textarea>
        <small class="char-note">
          <span class="char" data-max="65535">0</span> karakter
        </small>
      </div>

      <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
      <button class="btn" type="submit">Simpan</button>
      <?php if ($flash): ?><div class="msg"><?= htmlspecialchars($flash) ?></div><?php endif; ?>
    </form>
  </div>
</div>

<script>
  const MIN_HEIGHT = 36;
  function autoGrow(el){
    el.style.height = 'auto';
    const h = Math.max(MIN_HEIGHT, el.scrollHeight);
    el.style.height = h + 'px';
  }

  // init tinggi & counter
  document.addEventListener('DOMContentLoaded', function(){
    const ta = document.querySelector('.agenda-input');
    if (ta) {
      autoGrow(ta);
      const note = document.querySelector('.char');
      const max = Number(note?.dataset.max || '65535');
      const update = () => { if(note) note.textContent = (ta.value || '').length + ' / ' + max; };
      ta.addEventListener('input', update);
      update();
    }
  });
</script>
</body>
</html>
