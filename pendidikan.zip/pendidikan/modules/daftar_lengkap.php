<?php
// File: modules/daftar_lengkap.php

/* ===== 1) Koneksi (cari koneksi.php di beberapa lokasi) ===== */
ini_set('display_errors', 1);
error_reporting(E_ALL);

$koneksiCandidates = [
  __DIR__ . '/../koneksi.php',        // <root>/koneksi.php
  __DIR__ . '/../../koneksi.php',     // jika modules/ lebih dalam
  __DIR__ . '/../includes/koneksi.php',
  __DIR__ . '/koneksi.php',           // kalau ditempatkan sejajar (darurat)
];

$koneksiLoaded = false;
foreach ($koneksiCandidates as $kfile) {
  if (is_file($kfile)) {
    require_once $kfile;
    $koneksiLoaded = true;
    break;
  }
}
if (!$koneksiLoaded) {
  die(
    "Tidak menemukan file koneksi.php. Coba letakkan koneksi.php di salah satu path berikut:<br>" .
    implode("<br>", array_map('htmlspecialchars', $koneksiCandidates))
  );
}
if (!isset($conn) || !$conn) {
  die("Koneksi DB gagal. Cek kredensial di koneksi.php");
}
mysqli_set_charset($conn, 'utf8mb4');

/* ===== 2) Parameter jenjang ===== */
$j = isset($_GET['j']) ? strtoupper(trim($_GET['j'])) : '';
if (!in_array($j, ['MA','MTS','MI'], true)) {
  die("Parameter jenjang tidak valid. Gunakan ?j=MA / MTS / MI");
}

/* ===== 3) Mapping tabel & kolom per jenjang =====
   EDIT bagian ini jika nama kolom/tabel di DB Anda berbeda */
$map = [
  'MA'  => [
    'table'  => 'ma',
    'no'     => 'no',
    'npsn'   => 'npsn_ma',
    'nsm'    => 'nsm_ma',
    'nama'   => 'nm_ma',        // ganti ke 'nm_madrasah' jika itu yang Anda pakai
    'kepsek' => 'kepsek_ma',
    'kec'    => 'kec_ma',
  ],
  'MTS' => [
    'table'  => 'mts',
    'no'     => 'no',
    'npsn'   => 'npsn_mts',
    'nsm'    => 'nsm_mts',
    'nama'   => 'nm_mts',
    'kepsek' => 'kepsek_mts',
    'kec'    => 'kec_mts',
  ],
  'MI'  => [
    'table'  => 'mi',
    'no'     => 'no',
    'npsn'   => 'npsn_mi',
    'nsm'    => 'nsm_mi',
    'nama'   => 'nm_mi',
    'kepsek' => 'kepsek_mi',
    'kec'    => 'kec_mi',
  ],
];

$cfg = $map[$j];

/* ===== 4) Query ===== */
$cols = [
  "{$cfg['no']}      AS no",
  "{$cfg['npsn']}    AS npsn",
  "{$cfg['nsm']}     AS nsm",
  "{$cfg['nama']}    AS nama",
  "{$cfg['kepsek']}  AS kepsek",
  "{$cfg['kec']}     AS kec",
];

$sql = "SELECT ".implode(", ", $cols)." FROM `{$cfg['table']}` ORDER BY {$cfg['no']} ASC";
$res = mysqli_query($conn, $sql);
if (!$res) {
  die("Query error: ".mysqli_error($conn)."<br><small>SQL: ".htmlspecialchars($sql)."</small>");
}
$total = mysqli_num_rows($res);

/* ===== 5) Link kembali ===== */
$backHref = "../".strtolower($j)."/index.php";
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8">
  <title>Daftar Lengkap — <?= htmlspecialchars($j) ?></title>
  <style>
    body{font-family:Arial, sans-serif;background:#f9fafb;margin:0;padding:20px}
    h2{color:#256c2d;margin:0 0 8px}
    .muted{color:#64748b;margin:0 0 16px}
    .container{max-width:1200px;margin:auto}
    a.back{display:inline-block;margin:0 0 12px;padding:8px 12px;background:#4caf50;color:#fff;text-decoration:none;border-radius:6px}
    a.back:hover{background:#2e7d32}
    table{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,.08)}
    th,td{border:1px solid #e5e7eb;padding:8px;text-align:left}
    th{background:#256c2d;color:#fff}
    tr:nth-child(even){background:#f3f4f6}
    .right{text-align:right}
  </style>
</head>
<body>
<div class="container">
  <h2>Daftar Lengkap Lembaga — <?= htmlspecialchars($j) ?></h2>
  <p class="muted">Menampilkan semua data dari tabel <strong><?= htmlspecialchars($cfg['table']) ?></strong> (<?= $total ?> baris)</p>

  <a class="back" href="<?= htmlspecialchars($backHref) ?>">← Kembali ke Dashboard <?= htmlspecialchars($j) ?></a>

  <table>
    <tr>
      <th style="width:80px">No</th>
      <th style="width:140px">NPSN</th>
      <th style="width:160px">NSM</th>
      <th>Nama Madrasah</th>
      <th style="width:240px">Nama Kepala Madrasah</th>
      <th style="width:180px">Kecamatan</th>
    </tr>
    <?php while($r = mysqli_fetch_assoc($res)): ?>
      <tr>
        <td class="right"><?= htmlspecialchars($r['no'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['npsn'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['nsm'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['nama'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['kepsek'] ?? '') ?></td>
        <td><?= htmlspecialchars($r['kec'] ?? '') ?></td>
      </tr>
    <?php endwhile; ?>
  </table>
</div>
</body>
</html>
