<?php
require __DIR__ . "/../includes/koneksi.php";

$j = isset($_GET['j']) ? strtoupper($_GET['j']) : '';
switch ($j) {
  case 'MA':  require __DIR__ . '/../ma/config.php'; break;
  case 'MTS': require __DIR__ . '/../mts/config.php'; break;
  case 'MI':  require __DIR__ . '/../mi/config.php'; break;
  default: die("Parameter jenjang tidak valid. Gunakan ?j=MA / MTS / MI");
}

$table = $cfg['table'];
$f     = $cfg['fields'];

// HANYA yang SUDAH MENGISI — urut NO
$sql = "SELECT * FROM `$table`
        WHERE {$f['agenda']} IS NOT NULL AND {$f['agenda']} <> ''
        ORDER BY {$f['no']} ASC";
$result = mysqli_query($conn, $sql);
if (!$result) die("Query error: " . mysqli_error($conn));
?>
<!DOCTYPE html><html lang="id"><head>
<meta charset="UTF-8">
<title>Sudah Mengisi — <?= htmlspecialchars($cfg['label']) ?></title>
<style>
  body{font-family:Arial, sans-serif;background:#f9fafb;margin:0;padding:20px}
  h2{color:#2e7d32}
  .container{max-width:1200px;margin:auto}
  a.back{display:inline-block;margin:0 0 10px;padding:8px 12px;background:#4caf50;color:#fff;
         text-decoration:none;border-radius:6px}
  a.back:hover{background:#2e7d32}
  table{border-collapse:collapse;width:100%;background:#fff;box-shadow:0 4px 12px rgba(0,0,0,.08)}
  th,td{border:1px solid #ddd;padding:8px;text-align:left}
  th{background:#2e7d32;color:#fff}
  tr:nth-child(even){background:#f2f2f2}
</style>
</head><body>
<div class="container">
  <h2>Madrasah Sudah Isi Agenda 2025 — <?= htmlspecialchars($cfg['label']) ?></h2>
  <a class="back" href="../<?= strtolower($cfg['label']) ?>/index.php">← Kembali ke Dashboard <?= htmlspecialchars($cfg['label']) ?></a>

  <table>
    <tr>
      <th>No</th>
      <th>Nama Madrasah</th>
      <th>Kecamatan</th>
      <th>Kepala Sekolah</th>
      <th>Agenda 2025</th>
    </tr>
    <?php while($row = mysqli_fetch_assoc($result)): ?>
    <tr>
      <td><?= htmlspecialchars($row[$f['no']]) ?></td>
      <td><?= htmlspecialchars($row[$f['nama']]) ?></td>
      <td><?= htmlspecialchars($row[$f['kec']]) ?></td>
      <td><?= htmlspecialchars($row[$f['kepsek']]) ?></td>
      <td><?= htmlspecialchars($row[$f['agenda']]) ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</div>
</body></html>
