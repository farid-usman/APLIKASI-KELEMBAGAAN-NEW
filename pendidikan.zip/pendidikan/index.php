<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Pendidikan Madrasah</title>
  <style>
    body {font-family: Segoe UI, Arial; background: linear-gradient(135deg, #4caf50, #2e7d32); margin:0; display:flex; justify-content:center; align-items:center; height:100vh;}
    .container {background:#fff; padding:40px; border-radius:16px; box-shadow:0 10px 25px rgba(0,0,0,.2); width:90%; max-width:600px; text-align:center;}
    h1 {color:#2e7d32; margin-top:0;}
    ul {list-style:none; padding:0;}
    li {margin:15px 0;}
    a {display:block; padding:15px; border-radius:12px; background:#4caf50; color:#fff; text-decoration:none; font-size:18px; font-weight:bold; transition:all .2s;}
    a:hover {background:#2e7d32; transform:translateY(-3px);}
  </style>
</head>
<body>
  <div class="container">
    <h1>Pendidikan Madrasah</h1>
    <p>Pilih jenjang untuk melanjutkan:</p>
    <ul>
      <li><a href="ma/index.php">Jenjang MA</a></li>
      <li><a href="mts/index.php">Jenjang MTs</a></li>
      <li><a href="mi/index.php">Jenjang MI</a></li>
      <li><a href="modules/hasil.php?scope=internal">Rekap Internal</a></li>
    </ul>
  </div>
</body>
</html>
