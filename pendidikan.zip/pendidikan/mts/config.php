<?php
$cfg = [
  'label' => 'MTS',
  'table' => 'mts',
  'fields' => [
    'id'     => 'id',           // pastikan ada kolom PK atau ID
    'no'     => 'no',
    'nsm'    => 'nsm_mts',
    'npsn'   => 'npsn_mts',
    'nama'   => 'nm_mts',     // <-- ganti sesuai kolom yang ada
    'kec'    => 'kec_mts',      // atau 'kecamatan'
    'kepsek' => 'kepsek_mts',   // atau 'kepala_sekolah'
    'tipe'   => 'tipe_mts',
    'hp'     => 'nohp_mts',  
    'agenda' => 'agenda2025',
  ],
];
