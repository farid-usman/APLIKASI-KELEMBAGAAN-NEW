<?php require __DIR__."/../includes/koneksi.php"; require __DIR__."/config.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <title>Agenda 2025 — <?=htmlspecialchars($cfg['label'])?></title>
  <style>
    body{font-family:Segoe UI,Arial;background:#f6f9f7;margin:0}
    .head{background:#2e7d32;color:#fff;padding:18px 22px;display:flex;justify-content:space-between;align-items:center}
    .wrap{padding:22px}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}
    a.card{display:block;background:#fff;border:1px solid #e5efe7;border-radius:12px;padding:16px;text-decoration:none;color:#0f172a}
    a.card:hover{box-shadow:0 8px 20px rgba(0,0,0,.08);transform:translateY(-2px)}
    .back{background:#fff;color:#2e7d32;padding:8px 14px;border-radius:8px;text-decoration:none;font-weight:bold}
    .back:hover{background:#e8f5e9}
    .sub{color:#64748b;font-size:12px;margin-top:4px}
  </style>
</head>
<body>
  <div class="head">
    <h2>Agenda 2025 — <?=htmlspecialchars($cfg['label'])?></h2>
    <a class="back" href="../index.php">← Kembali Halaman Awal</a>
  </div>
  <div class="wrap">
    <div class="grid">
      <a class="card" href="../modules/daftar_lengkap.php?j=MTS">
         Daftar Lengkap
        <div class="sub">No, NPSN, NSM, Nama Madrasah, Kepsek, Kecamatan</div>
      </a>

      <a class="card" href="../modules/isi_kegiatan.php?j=<?=urlencode($cfg['label'])?>&mode=all">
        Isi Kegiatan (Tampilkan Semua)
        <div class="sub">Edit cepat seluruh madrasah</div>
      </a>

      <a class="card" href="../modules/daftar_sudah.php?j=<?=urlencode($cfg['label'])?>">
        Sudah Mengisi
      </a>

      <a class="card" href="../modules/daftar_belum.php?j=<?=urlencode($cfg['label'])?>">
        Belum Mengisi
      </a>

      <a class="card" href="../modules/hasil.php?j=<?=urlencode($cfg['label'])?>">
        Rekap / Hasil
      </a>
    </div>
  </div>
</body>
</html>
